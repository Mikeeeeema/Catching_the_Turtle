﻿#Final Project
#Catch the turtle
#Runzhi Ma
#Mike Ma
#M005
#rma115
#There are 52cards totaly. The player need to enter how manyplayers does
#he want to play with.At the begining of the game, one card would be taken
#out as turtle.After dividing the cards, you need to take out the pairs.
#For therest of the card, we would begin to catch the turtle start with player
#who have least cards. When you get a card which can form the pair with the
#cards you have had, you need to take it out. Finally, who get that card which
#can not be in pair would be the turtle(loser).
#There is a editor mode which can help you see what cards do the computer have.


from graphics import*
import random

#FNC
def setbackround():
    #Set the background
    #GW
    win = GraphWin('Catching the Turtle', 1000,800)
    win.setBackground('lightblue')
    win.setCoords(0,0,20,16)
    return win

#FNC
def setfirstslide(win):
    #Setting the first slid, asking the user the name and click the "submit"
    #button
    #Slogan
    wel=Text(Point(10,13),"Welcome to Catch-The-Turtle")
    wel.setTextColor("red")
    wel.setSize(30)
    wel.draw(win)

    #Player's name and entry box
    nameinp=Entry(Point(8,8),8)
    nameinp.setSize(20)
    nameinp.draw(win)

    PN=Text(Point(8,9),"Player Name")
    PN.setSize(23)
    PN.draw(win)

    #submit button
    lf1=Point(11,7.5)
    ur1=Point(13,8.5)
    sub=Rectangle(lf1,ur1)
    subt=Text(Point(12,8),"submit")
    subt.setSize(20)
    subt.draw(win)
    sub.draw(win)

    #check the click button
    if ifclick(lf1,ur1,win):
        name=nameinp.getText()
        nameinp.undraw()
        PN.undraw()
        subt.undraw()
        sub.undraw()
        wel.undraw()
        return name

#FNC
def checkinf(name,win):
    #second slide
    #Check the basic infomation
    nump=Text(Point(10,10.5),"The number of players: 3")
    nump.setSize(25)
    nump.draw(win)
    pn=Text(Point(10,9.5),"The name of the Player: "+name)
    pn.setSize(25)
    pn.draw(win)
    lf2=Point(9,7)
    ur2=Point(11,8)
    sr=Rectangle(lf2,ur2)
    sr.draw(win)
    st=Text(Point(10,7.5),"START")
    st.setSize(20)
    st.setTextColor("red")
    st.draw(win)

    #Click the START, close all the objects except the title
    if ifclick(lf2,ur2,win):
        nump.undraw()
        pn.undraw()
        sr.undraw()
        st.undraw()


#FNC
#Click the button  if the click point is not with in the button, the user need
#to click continuely until the point is within the button.
def ifclick(LF,UR,win):
    #IMS Called this function a lot of times
    p=win.getMouse()
    while not(LF.getX()<p.getX()<UR.getX() and LF.getY()<p.getY()<UR.getY()):
        p=win.getMouse()
    return True

#CLOD
class card:
    #a means the deatil of the card, x and y mean the position of the low left point
    def __init__(self,a,x,y):
        self.cardinf1=a
        self.cardloc=Rectangle(Point(x,y),Point(x+.8,y+.6))
        self.cardcdloc=Text(Point(x+.2,y+.4),str(self.cardinf1))
        self.cardcdloc.setSize(8)
        self.x=x
        self.y=y

    #reutrn the detail of the card
    def cardinf(self):
        return self.cardinf1

    #display the whole card including the detail and the rectangle
    def displaycard(self,win):
        self.cardloc.draw(win)
        self.cardcdloc.draw(win)

    #displayer only the rectangle but not the card detail  
    def displayblank(self,win):
        self.cardloc.draw(win)

    #should the card detail
    def godview(self,win):
        self.cardcdloc.draw(win)

    #only undraw the detail
    def closegodview(self):
        self.cardcdloc.undraw()

    #only undraw the rectangle
    def undrawblank(self):
        self.cardloc.undraw()

    #undraw the whole card
    def undraw(self):
        self.cardloc.undraw()
        self.cardcdloc.undraw()

#FNC
#IFL
#generate a new card array, take out the turtle card, divid the card ramdonly
def generate():
    #IEB
    #import the cards from the txt file 
    infile=open("poker.txt","r")
    poker = []
    #IFL
    #put all the file in a list
    for i in infile:
        poker.append(i)
    #clean the strip in each string
    for j in range(len(poker)):
        poker[j]=poker[j].rstrip()
    random.shuffle(poker)
    mike=[]
    p1=[]
    p2=[]
    #RND
    #take out the turtle card
    turtle=poker.pop(random.randrange(0,52))
    #divide the card randomly
    i=0
    while i<51:
        #LOOD
        mike.append(poker[i])
        i+=1
        #LOOD
        p1.append(poker[i])
        i+=1
        #LOOD
        p2.append(poker[i])
        i+=1
    return mike,p1,p2,turtle,infile

#it is helpful for the sort method when the elements in the list are objects    
def getcardinf(mike):
    name=mike.cardinf()
    return name

#FNC
#this method would sort the card first and take out all the cards which can form
#pairs with another card and it will return all the card objects that are removed
def takeOutPairs(lst,win,mike,p1,p2):
    #to know if the lst is mike or p1 or p2
    if lst==mike:
        way=0
    elif lst==p1:
        way=1
    elif lst==p2:
        way=2
    #to know if the lst is mike or p1 or p2
    #undraw the cards
    for i in lst:
        if way==0:
            i.undraw()
        elif way==1:
            i.undrawblank()
        elif way==2:
            i.undrawblank()
    #sort the lst 
    lst.sort(key=getcardinf)
    removelstpos = []
    removelst=[]
    i=0
    while i<len(lst)-1:
        for j in range(i+1,len(lst)):
            if lst[i].cardinf()[0] == lst[j].cardinf()[0]:
                removelstpos.append(i)
                removelstpos.append(j)
                i=j
                break
        i+=1
    removelstpos.reverse()
    for j in removelstpos:
        removelst.append(lst.pop(j))
    #redraw cards
    if way==0:
        for i in range(len(lst)):
            lst[i]=card(lst[i].cardinf(),3+.85*i,.5)
            lst[i].displaycard(win)
    elif way==1:
        for i in range(len(lst)):
            lst[i]=card(lst[i].cardinf(),1.5,13.7-.7*i)
            lst[i].displayblank(win)
    elif way==2:
        for i in range(len(lst)):
            lst[i]=card(lst[i].cardinf(),17.7,13.7-.7*i)
            lst[i].displayblank(win)
    #return  被移除的牌
    return removelst

#put the min lst in the middle of the large ls
#FNC
def removeMinToMiddle(lst,minlst):
    indexmin=lst.index(minlst)
    lst[indexmin],lst[1]=lst[1],lst[indexmin]
    
#find the min list, which has minimum objects
def findmin(lst1,lst2,lst3):
    min=lst1
    for i in [lst1,lst2,lst3]:
        if len(i)<len(min):
            min=i
            
    return min

#FNC
#remove the cards to the middle display it in ramdon sequence and symmetry to
#the mid line
def middle(poker,win,mike,p1,p2):
    if poker==mike:
        way=0
    elif poker==p1:
        way=1
    elif poker==p2:
        way=2
    random.shuffle(poker)
    if len(poker)%2==1:
        mid=len(poker)//2
        k=0
        
        for i in range(mid,0,-1):
            poker[mid-i]=card(poker[k].cardinf(),10-.9*i,9)
            poker[mid+i]=card(poker[len(poker)-k-1].cardinf(),10+.9*i,9)
            k+=1
            if way==0:
                poker[mid-i].displaycard(win)
                poker[mid+i].displaycard(win)
            else:
                poker[mid-i].displayblank(win)
                poker[mid+i].displayblank(win)
        poker[mid]=card(poker[k].cardinf(),10,9)
        #电脑不显示
        if way==0:
            poker[mid].displaycard(win)
        else:
            poker[mid].displayblank(win)
    else:
        mid=len(poker)//2
        k=0
        for i in range(mid,0,-1):
            poker[mid-i]=card(poker[k].cardinf(),10-.9*(i-.5),9)
            poker[mid+i-1]=card(poker[len(poker)-k-1].cardinf(),10+.9*(i-.5),9)
            k+=1
            #电脑不显示
            if way==0:
                poker[mid-i].displaycard(win)
                poker[mid+i-1].displaycard(win)
            else:
                poker[mid-i].displayblank(win)
                poker[mid+i-1].displayblank(win)
    return poker

#ask the user which card does he wants to take
#FNC
def askpos(win,n):
    #OTXT
    que=Text(Point(9,1.5),"Which card do you want to choose:")
    #IEB
    ent=Entry(Point(11,1.5),3)
    que.setSize(10)
    ent.setSize(10)
    que.draw(win)
    ent.draw(win)
    ent.setText(-1)
    win.getMouse()
    pos=int(ent.getText())-1
    while not (-1<pos<n):
        #OTXT
        warn=Text(Point(9,1.8),"Please enter again!")
        warn.draw(win)
        win.getMouse()
        warn.undraw()
        pos=int(ent.getText())
    que.undraw()
    ent.undraw()
    return pos

#the second part of the game one play take a ramdon card from the next player,
#when it can form a pair with the card that he has had he need to takeOutPairs
#and the pair will be display in the middle of the screen. And then contiune.
#If it can not be form a pair, the card lst will be sorted and round pass.
#when the user is going to take a card, he need to type the number between 0 and
#len(lst)-1.
#FNC
def takecard(player,nextone,win,mike,p1,p2):
    #to know if the lst is mike or p1 or p2
    if player==mike:
        way=0
    elif player==p1:
        way=1
    elif player==p2:
        way=2
    #to know if the lst is mike or p1 or p2
    if nextone==mike:
        way1=0
    elif nextone==p1:
        way1=1
    elif nextone==p2:
        way1=2
    win.getMouse()
    for i in nextone:
        if way1==0:
            i.undraw()
        elif way1==1:
            i.undrawblank()
        elif way1==2:
            i.undrawblank()
    #out the nextone lst(the lst which is going to be taken one card) in the middle
    nextone=middle(nextone,win,mike,p1,p2)
    win.getMouse()
    #when the user is going to take a card, he need to type the number between 0 and
    #len(lst)-1.
    if player==mike:
        takenpos=askpos(win,len(nextone))
    #when it is computer's turn to take, it will take one card randomly
    else:
        #RND
        takenpos=random.randrange(0,len(nextone))
    for i in nextone:
        if way1==0:
            i.undraw()
        elif way1==1:
            i.undrawblank()
        elif way1==2:
            i.undrawblank()
    #take out the one card that is asker before in the nextone   
    betakencard=nextone.pop(takenpos)
    win.getMouse()
    if way==0 or way1==0:
        betakencard.displaycard(win)
    else:
        betakencard.displayblank(win)
    
    
    win.getMouse()
    #draw back the card
    if way1==0:
        for i in range(len(nextone)):
            nextone[i]=card(nextone[i].cardinf(),3+.85*i,.5)
            nextone[i].displaycard(win)
    elif way1==1:
        for i in range(len(nextone)):
            nextone[i]=card(nextone[i].cardinf(),1.5,13.7-.7*i)
            nextone[i].displayblank(win)
    elif way1==2:
        for i in range(len(nextone)):
            nextone[i]=card(nextone[i].cardinf(),17.7,13.7-.7*i)
            nextone[i].displayblank(win)
    win.getMouse()
    if way==0 or way1==0:
        betakencard.undraw()
    else:
        betakencard.undrawblank()
    for i in player:
        if way==0:
            i.undraw()
        elif way==1:
            i.undrawblank()
        elif way==2:
            i.undrawblank()
    win.getMouse()
    player.append(betakencard)
    if way==0:
        for i in range(len(player)):
            player[i]=card(player[i].cardinf(),3+.85*i,.5)
            player[i].displaycard(win)
    elif way==1:
        for i in range(len(player)):
            player[i]=card(player[i].cardinf(),1.5,13.7-.7*i)
            player[i].displayblank(win)
    elif way==2:
        for i in range(len(player)):
            player[i]=card(player[i].cardinf(),17.7,13.7-.7*i)
            player[i].displayblank(win)    
    win.getMouse()  
    removelst=takeOutPairs(player,win,mike,p1,p2)
    return removelst

#when one of the player send out all the cards, he is the winner
def checklaststep(mike,p1,p2):
    if len(mike)==0 or len(p1)==0 or len(p2)==0:
        return True

#make the takeoutpairs button
def takeOutPairsButton(win):
    lf=Point(8,1.6)
    rh=Point(12,2.6)
    takeOutPairsbutton=Rectangle(lf,rh)
    #OTXT
    text=Text(Point(10,2.1),"Take Out Pairs")
    text.setSize(20)
    takeOutPairsbutton.draw(win)
    text.draw(win)
    if ifclick(lf,rh,win):
        takeOutPairsbutton.undraw()
        text.undraw()

#display removelst in the middle of the screen
#FNC
def showRemovelst(removelst,win):
    if len(removelst)!=0:
        add=0.9
        for i in range(len(removelst)):
            removelst[i]=card(removelst[i].cardinf(),9.1+add,7.7)
            removelst[i].displaycard(win)
            add+=0.9
        win.getMouse()
        for k in removelst:
            k.undraw()

#after the game, different ending has different scenery. win or lost
#FNC
def end(win,mike,turtle,lst,infile):
    if len(mike)==0:
        #show the turtle card
        turtle.godview(win)
        #OTXT
        con=Text(Point(10,8),"Congratulations! You are the winner!")
        con.setTextColor("red")
        con.setSize(15)
        con.draw(win)
        outfile=open("end.txt","w")
        #OFL
        #put the card left in the output file
        print(turtle.cardinf(),file=outfile)
        for i in lst:
            for j in i:
                print(j.cardinf(),end=" ",file=outfile)
            print(file=outfile)
        win.getMouse()
        win.close()
        infile.close()
        outfile.close()
    else:
        #show the turtle card
        turtle.godview(win)
        #OTXT
        los=Text(Point(10,8),"So sad! You lose the game.")
        los.setTextColor("red")
        los.setSize(15)
        los.draw(win)
        outfile=open("end.txt","w")
        #OFL
        #put the card left in the output file
        print(turtle.cardinf(),file=outfile)
        for i in lst:
            for j in i:
                print(j.cardinf(),end=" ",file=outfile)
            print(file=outfile)
        win.getMouse()
        win.close()
        infile.close()
        outfile.close()

#if I click the godview button, all the detail will be showen, if I click it
#again, all of them will be hided again and the game can be continued.
#if I do not click the godview button, it will disappear directly and the game
#will be continues
#FNC
def godview(win,p1,p2,turtle):
    lf=Point(1,14.5)
    ur=Point(3,15.5)
    god=Rectangle(lf,ur)
    #OTXT
    godt=Text(Point(2,15),"GOD VIEW")
    godt.setSize(18)
    godt.draw(win)
    god.draw(win)
    p=win.getMouse()
    if lf.getX()<p.getX()<ur.getX() and lf.getY()<p.getY()<ur.getY():
        for i in p1:
            i.godview(win)
        for i in p2:
            i.godview(win)
        turtle.godview(win)
        win.getMouse()
        for i in p1:
            i.closegodview()
        for i in p2:
            i.closegodview()
        turtle.closegodview()
        win.getMouse()
        godt.undraw()
        god.undraw()
    else:
        godt.undraw()
        god.undraw()

    


    
    

            
def main():
    win=setbackround()
    name=setfirstslide(win)
    checkinf(name,win)
    
   

    #generate the cards, divide the cards and take out the turtle card
    mike,p1,p2,turtle,infile=generate()
    #show the blank turtle card in the lower left conner of the screen
    turtle=card(turtle,1,1)
    turtle.displayblank(win)
    #put all the cards lists in a big list
    lst=[mike,p1,p2]
    #add card class to each hand list
    #LOOD
    for k in range(len(mike)):
        mike[k]=card(mike[k],3+.85*k,.5)
        mike[k].displaycard(win)
        p1[k]=card(p1[k],1.5,13.7-.7*k)
        p1[k].displayblank(win)
        p2[k]=card(p2[k],17.7,13.7-.7*k)
        p2[k].displayblank(win)
    #add the takeoutpair button and the god view button
    godview(win,p1,p2,turtle)
    takeOutPairsButton(win)
    
    #take out pairs (sort method inside the card list) return value useless
    #LOOD
    for j in [mike,p1,p2]:
        #GW
        oneround=takeOutPairs(j,win,mike,p1,p2)
    godview(win,p1,p2,turtle)
    #find the player who has least cards
    minlst=findmin(mike,p1,p2)
    #put the lst who has the minimum lst in the middle of the lst
    removeMinToMiddle(lst,minlst)
    #start the game take one card from the other perspon
    #LOOD
    #seond part of the game, continue the takeonecard untill one player do not
    #has any cards
    while len(mike)!=0 and len(p1)!=0 and len(p2)!=0:
        #GW
        removelst=takecard(minlst,lst[2],win,mike,p1,p2)
        showRemovelst(removelst,win)
        if checklaststep(mike,p1,p2):
            break
        godview(win,p1,p2,turtle)
        removelst=takecard(lst[2],lst[0],win,mike,p1,p2)
        showRemovelst(removelst,win)
        if checklaststep(mike,p1,p2):
            break
        godview(win,p1,p2,turtle)
        removelst=takecard(lst[0],minlst,win,mike,p1,p2)
        showRemovelst(removelst,win)
        godview(win,p1,p2,turtle)
    #GW
    #end slide output the rest of card information
    end(win,mike,turtle,lst,infile)
    
main()
